import express from 'express';
import path from 'path';
import cors from 'cors';
import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

// ES module equivalent of __dirname
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Trust proxy for shared hosting
app.set('trust proxy', true);

// Middleware
app.use(cors({
  origin: process.env.NODE_ENV === 'production' 
    ? [process.env.FRONTEND_URL, process.env.DOMAIN_URL].filter(Boolean)
    : true,
  credentials: true
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Serve static files from the current directory with proper headers
app.use(express.static(__dirname, {
  maxAge: process.env.NODE_ENV === 'production' ? '1y' : '0',
  etag: true,
  lastModified: true
}));

// Database connection configuration
const dbConfig = {
  host: process.env.VITE_MYSQL_HOST || process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.VITE_MYSQL_PORT || process.env.DB_PORT || '3306'),
  user: process.env.VITE_MYSQL_USER || process.env.DB_USER || 'root',
  password: process.env.VITE_MYSQL_PASSWORD || process.env.DB_PASSWORD || '',
  database: process.env.VITE_MYSQL_DATABASE || process.env.DB_NAME || 'storyboard',
  waitForConnections: true,
  connectionLimit: process.env.NODE_ENV === 'production' ? 5 : 10,
  queueLimit: 0
};

// Create connection pool
const pool = mysql.createPool(dbConfig);

// Database connection test
async function testConnection() {
  try {
    const connection = await pool.getConnection();
    console.log('✅ Database connection successful');
    connection.release();
    return true;
  } catch (error) {
    console.error('❌ Database connection failed:', error.message);
    console.error('🔧 Please ensure MySQL is running and credentials are correct');
    return false; // Return false instead of exiting
  }
}

// API Routes
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    message: 'Story Board Engine Server is running',
    timestamp: new Date().toISOString()
  });
});

// Database test endpoint
app.get('/api/db-test', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT 1 as test');
    res.json({ 
      status: 'OK', 
      message: 'Database connection successful',
      data: rows 
    });
  } catch (error) {
    res.status(500).json({ 
      status: 'ERROR', 
      message: 'Database connection failed',
      error: error.message 
    });
  }
});

// Authentication endpoints
app.post('/api/auth/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    
    if (!username || !password) {
      return res.status(400).json({ 
        status: 'ERROR', 
        message: 'Username and password are required' 
      });
    }

    // For demo purposes, use hardcoded credentials since database is not connected
    if (username === 'admin' && password === 'admin123') {
      res.json({
        status: 'OK',
        id: '1',
        username: 'admin',
        email: 'admin@example.com',
        role: 'admin'
      });
      return;
    }

    // If database is available, try to check against it
    try {
      const [rows] = await pool.execute(
        'SELECT id, username, email, role FROM users WHERE username = ? AND password_hash = ?',
        [username, password]
      );

      if (rows.length > 0) {
        const user = rows[0];
        res.json({
          status: 'OK',
          id: user.id,
          username: user.username,
          email: user.email,
          role: user.role
        });
        return;
      }
    } catch (dbError) {
      console.log('Database not available, using hardcoded credentials only');
    }

    // Invalid credentials
    res.status(401).json({ 
      status: 'ERROR', 
      message: 'Invalid username or password' 
    });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ 
      status: 'ERROR', 
      message: 'Internal server error' 
    });
  }
});

app.get('/api/auth/me', async (req, res) => {
  // For now, return unauthorized since we don't have session management
  res.status(401).json({ 
    status: 'ERROR', 
    message: 'Not authenticated' 
  });
});

app.post('/api/auth/logout', (req, res) => {
  // For now, just return success
  res.json({ 
    status: 'OK', 
    message: 'Logged out successfully' 
  });
});

// API endpoint for story board data (example)
app.get('/api/storyboards', async (req, res) => {
  try {
    // This is a placeholder - you can implement your actual database queries here
    const [rows] = await pool.execute('SELECT * FROM storyboards LIMIT 10');
    res.json({ 
      status: 'OK', 
      data: rows 
    });
  } catch (error) {
    // If table doesn't exist, return empty array
    res.json({ 
      status: 'OK', 
      data: [],
      message: 'No storyboards table found - this is normal for initial setup'
    });
  }
});

// Create storyboard endpoint (example)
app.post('/api/storyboards', async (req, res) => {
  try {
    const { title, description, content } = req.body;
    
    // Create table if it doesn't exist
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS storyboards (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        content JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);
    
    const [result] = await pool.execute(
      'INSERT INTO storyboards (title, description, content) VALUES (?, ?, ?)',
      [title, description, JSON.stringify(content)]
    );
    
    res.json({ 
      status: 'OK', 
      message: 'Storyboard created successfully',
      id: result.insertId 
    });
  } catch (error) {
    res.status(500).json({ 
      status: 'ERROR', 
      message: 'Failed to create storyboard',
      error: error.message 
    });
  }
});

// Projects API endpoints
app.get('/api/projects', async (req, res) => {
  try {
    // Create projects table if it doesn't exist
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS projects (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title_ar VARCHAR(255) NOT NULL,
        title_en VARCHAR(255) NOT NULL,
        description_ar TEXT,
        description_en TEXT,
        cover_image VARCHAR(500),
        gallery JSON,
        status ENUM('draft', 'published', 'completed', 'in-progress') DEFAULT 'draft',
        location VARCHAR(255),
        location_en VARCHAR(255),
        year VARCHAR(4),
        participants INT DEFAULT 0,
        trees_planted INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);

    const [rows] = await pool.execute('SELECT * FROM projects ORDER BY created_at DESC');
    res.json({ 
      status: 'OK', 
      data: rows 
    });
  } catch (error) {
    // Return sample data if database is not available
    const sampleProjects = [
      {
        id: 1,
        title_ar: "المحيط الأخضر وليبانا شراكة من أجل الغطاء النباتي",
        title_en: "Green Ocean and Libyana A Partnership for Vegetation Cover",
        description_ar: "وبالشراكة الفاعلة مع شركة ليبانا للهاتف المحمول قامت جمعية المحيط الأخضر للحلول البيئية بتنفيذ حملة تشجير تهدف إلى الإسهام في حماية البيئة ودعم الاستدامة البيئية في عدة مناطق.",
        description_en: "In active partnership with Libyana Mobile Phone Company, the Green Ocean Association for Environmental Solutions implemented a tree planting campaign aimed at contributing to environmental protection and supporting environmental sustainability in several regions.",
        location: "ليبيا",
        location_en: "Libya",
        status: "completed",
        year: "2024",
        participants: 150,
        trees_planted: 500,
        cover_image: "/placeholder.svg",
        gallery: []
      }
    ];
    
    res.json({ 
      status: 'OK', 
      data: sampleProjects,
      message: 'Using sample data - database not available'
    });
  }
});

app.post('/api/projects', async (req, res) => {
  try {
    const { 
      titleAr, 
      titleEn, 
      descriptionAr, 
      descriptionEn, 
      coverImage, 
      gallery, 
      status,
      location,
      locationEn,
      year,
      participants,
      treesPlanted
    } = req.body;
    
    // Create projects table if it doesn't exist
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS projects (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title_ar VARCHAR(255) NOT NULL,
        title_en VARCHAR(255) NOT NULL,
        description_ar TEXT,
        description_en TEXT,
        cover_image VARCHAR(500),
        gallery JSON,
        status ENUM('draft', 'published', 'completed', 'in-progress') DEFAULT 'draft',
        location VARCHAR(255),
        location_en VARCHAR(255),
        year VARCHAR(4),
        participants INT DEFAULT 0,
        trees_planted INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);
    
    const [result] = await pool.execute(
      `INSERT INTO projects (title_ar, title_en, description_ar, description_en, cover_image, gallery, status, location, location_en, year, participants, trees_planted) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [titleAr, titleEn, descriptionAr, descriptionEn, coverImage, JSON.stringify(gallery || []), status || 'draft', location, locationEn, year, participants || 0, treesPlanted || 0]
    );
    
    res.json({ 
      status: 'OK', 
      message: 'Project created successfully',
      id: result.insertId 
    });
  } catch (error) {
    res.status(500).json({ 
      status: 'ERROR', 
      message: 'Failed to create project',
      error: error.message 
    });
  }
});

app.put('/api/projects/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { 
      titleAr, 
      titleEn, 
      descriptionAr, 
      descriptionEn, 
      coverImage, 
      gallery, 
      status,
      location,
      locationEn,
      year,
      participants,
      treesPlanted
    } = req.body;
    
    const [result] = await pool.execute(
      `UPDATE projects SET title_ar = ?, title_en = ?, description_ar = ?, description_en = ?, 
       cover_image = ?, gallery = ?, status = ?, location = ?, location_en = ?, year = ?, 
       participants = ?, trees_planted = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
      [titleAr, titleEn, descriptionAr, descriptionEn, coverImage, JSON.stringify(gallery || []), status, location, locationEn, year, participants || 0, treesPlanted || 0, id]
    );
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ 
        status: 'ERROR', 
        message: 'Project not found' 
      });
    }
    
    res.json({ 
      status: 'OK', 
      message: 'Project updated successfully' 
    });
  } catch (error) {
    res.status(500).json({ 
      status: 'ERROR', 
      message: 'Failed to update project',
      error: error.message 
    });
  }
});

app.delete('/api/projects/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    const [result] = await pool.execute('DELETE FROM projects WHERE id = ?', [id]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ 
        status: 'ERROR', 
        message: 'Project not found' 
      });
    }
    
    res.json({ 
      status: 'OK', 
      message: 'Project deleted successfully' 
    });
  } catch (error) {
    res.status(500).json({ 
      status: 'ERROR', 
      message: 'Failed to delete project',
      error: error.message 
    });
  }
});

// Image upload endpoint (placeholder - in production you'd use multer or similar)
app.post('/api/upload', (req, res) => {
  try {
    // This is a placeholder for file upload functionality
    // In a real implementation, you would use multer or similar middleware
    // to handle file uploads and save them to a storage service or local directory
    
    const { file, filename } = req.body;
    
    if (!file) {
      return res.status(400).json({ 
        status: 'ERROR', 
        message: 'No file provided' 
      });
    }
    
    // Simulate file upload success
    const uploadedUrl = `/uploads/${filename || 'uploaded-image.jpg'}`;
    
    res.json({ 
      status: 'OK', 
      message: 'File uploaded successfully',
      url: uploadedUrl 
    });
  } catch (error) {
    res.status(500).json({ 
      status: 'ERROR', 
      message: 'Failed to upload file',
      error: error.message 
    });
  }
});

// Contacts API endpoints
app.get('/api/contacts', async (req, res) => {
  try {
    // Create contacts table if it doesn't exist
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS contacts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        phone VARCHAR(50),
        subject VARCHAR(255) NOT NULL,
        message TEXT NOT NULL,
        status ENUM('PENDING', 'REVIEWED', 'RESPONDED', 'CLOSED') DEFAULT 'PENDING',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);

    const [rows] = await pool.execute('SELECT * FROM contacts ORDER BY created_at DESC');
    res.json({ 
      status: 'OK', 
      data: rows 
    });
  } catch (error) {
    res.json({ 
      status: 'OK', 
      data: [],
      message: 'No contacts available - database not connected'
    });
  }
});

app.post('/api/contacts', async (req, res) => {
  try {
    const { name, email, phone, subject, message } = req.body;
    
    if (!name || !email || !subject || !message) {
      return res.status(400).json({ 
        status: 'ERROR', 
        message: 'Name, email, subject, and message are required' 
      });
    }
    
    // Create contacts table if it doesn't exist
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS contacts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        phone VARCHAR(50),
        subject VARCHAR(255) NOT NULL,
        message TEXT NOT NULL,
        status ENUM('PENDING', 'REVIEWED', 'RESPONDED', 'CLOSED') DEFAULT 'PENDING',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);
    
    const [result] = await pool.execute(
      'INSERT INTO contacts (name, email, phone, subject, message) VALUES (?, ?, ?, ?, ?)',
      [name, email, phone, subject, message]
    );
    
    res.json({ 
      status: 'OK', 
      message: 'Contact message sent successfully',
      id: result.insertId 
    });
  } catch (error) {
    res.status(500).json({ 
      status: 'ERROR', 
      message: 'Failed to send contact message',
      error: error.message 
    });
  }
});

// Settings API endpoints
app.get('/api/settings', async (req, res) => {
  try {
    // Create settings table if it doesn't exist
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS settings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        setting_key VARCHAR(255) UNIQUE NOT NULL,
        setting_value JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);

    const [rows] = await pool.execute('SELECT * FROM settings');
    
    // Convert to object format
    const settings = {};
    rows.forEach(row => {
      settings[row.setting_key] = row.setting_value;
    });
    
    res.json({ 
      status: 'OK', 
      data: settings 
    });
  } catch (error) {
    // Return default settings if database is not available
    const defaultSettings = {
      socialLinks: {
        facebook: '',
        twitter: '',
        instagram: '',
        linkedin: '',
        youtube: ''
      },
      basicData: {
        siteName: 'المحيط الأخضر',
        siteNameEn: 'Green Ocean',
        description: 'جمعية بيئية تهدف لحماية البيئة',
        descriptionEn: 'Environmental association aimed at protecting the environment'
      },
      imageSettings: {
        logo: '/placeholder.svg',
        heroImage: '/placeholder.svg',
        aboutImage: '/placeholder.svg'
      }
    };
    
    res.json({ 
      status: 'OK', 
      data: defaultSettings,
      message: 'Using default settings - database not connected'
    });
  }
});

app.put('/api/settings/social-links', async (req, res) => {
  try {
    const socialLinks = req.body;
    
    // Create settings table if it doesn't exist
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS settings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        setting_key VARCHAR(255) UNIQUE NOT NULL,
        setting_value JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);
    
    await pool.execute(
      'INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = CURRENT_TIMESTAMP',
      ['socialLinks', JSON.stringify(socialLinks)]
    );
    
    res.json({ 
      status: 'OK', 
      message: 'Social links updated successfully' 
    });
  } catch (error) {
    res.status(500).json({ 
      status: 'ERROR', 
      message: 'Failed to update social links',
      error: error.message 
    });
  }
});

app.put('/api/settings/basic-data', async (req, res) => {
  try {
    const basicData = req.body;
    
    await pool.execute(
      'INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = CURRENT_TIMESTAMP',
      ['basicData', JSON.stringify(basicData)]
    );
    
    res.json({ 
      status: 'OK', 
      message: 'Basic data updated successfully' 
    });
  } catch (error) {
    res.status(500).json({ 
      status: 'ERROR', 
      message: 'Failed to update basic data',
      error: error.message 
    });
  }
});

app.put('/api/settings/image-settings', async (req, res) => {
  try {
    const imageSettings = req.body;
    
    await pool.execute(
      'INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = CURRENT_TIMESTAMP',
      ['imageSettings', JSON.stringify(imageSettings)]
    );
    
    res.json({ 
      status: 'OK', 
      message: 'Image settings updated successfully' 
    });
  } catch (error) {
    res.status(500).json({ 
      status: 'ERROR', 
      message: 'Failed to update image settings',
      error: error.message 
    });
  }
});

// Catch all handler: send back React's index.html file for client-side routing
// Catch all handler: send back React's index.html file for client-side routing
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Server error:', err);
  const isDevelopment = process.env.NODE_ENV !== 'production';
  res.status(500).json({ 
    error: 'Internal server error',
    ...(isDevelopment && { details: err.message, stack: err.stack })
  });
});

// Graceful shutdown
// Global server variable for graceful shutdown
let server;

const gracefulShutdown = () => {
  console.log('🔄 Received shutdown signal, closing server gracefully...');
  if (server) {
    server.close(() => {
      console.log('✅ Server closed successfully');
      if (pool) {
        pool.end(() => {
          console.log('✅ Database pool closed');
          process.exit(0);
        });
      } else {
        process.exit(0);
      }
    });
  } else {
    process.exit(0);
  }
};

async function startServer() {
  try {
    // Test database connection before starting server
    const isDbConnected = await testConnection();
    
    if (!isDbConnected) {
      console.warn('⚠️  Database connection failed, but starting server anyway for static files');
      console.warn('📝 Note: Database-dependent features will not work until connection is established');
    }
    
    server = app.listen(PORT, () => {
      console.log(`🚀 Server running on port ${PORT}`);
      console.log(`📁 Serving static files from: ${__dirname}`);
      console.log(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
      if (isDbConnected) {
        console.log('✅ Database connected and ready');
      } else {
        console.log('⚠️  Server running without database connection');
      }
    });

    // Handle server errors
    server.on('error', (error) => {
      if (error.code === 'EADDRINUSE') {
        console.error(`❌ Port ${PORT} is already in use`);
        process.exit(1);
      } else {
        console.error('❌ Server error:', error);
      }
    });

    // Graceful shutdown handlers
    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);
    
    return server;
  } catch (error) {
    console.error('❌ Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server
startServer();
export default app;